<?php

include_once("DataAccess/AccesoDatos.php");

class Relacion{
    public $nombre;
    public $apellido;
    public $pelicula;
    public $ruta_foto;

 }